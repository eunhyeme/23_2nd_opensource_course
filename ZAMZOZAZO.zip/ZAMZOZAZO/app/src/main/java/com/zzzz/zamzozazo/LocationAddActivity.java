package com.zzzz.zamzozazo;
import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class LocationAddActivity extends AppCompatActivity implements OnMapReadyCallback {

    //지도 관리
    GoogleMap googleMap;
    private FragmentManager fragmentManager;
    private MapFragment mapFragment;

    //UI 관리
    private TextView tvLatitude, tvLongitude;
    private Button btnGetLocation,setAlarm;
    private EditText editText;
    //위도경도 초기값=그리니치천문대
    double lat=51.5;
    double lon=0.0015;
    public Location location;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String TAG="메인";

        Log.d(TAG, "onCreate: 1");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locationadd);
        Log.d(TAG, "onCreate: 2");
        //지도 요소
        fragmentManager=getFragmentManager();
        mapFragment=(MapFragment)fragmentManager.findFragmentById(R.id.googlemap);
        mapFragment.getMapAsync(this);
        Log.d(TAG, "onCreate: 3");
        // UI 요소 초기화
        tvLatitude = findViewById(R.id.tvLatitude);//textview
        tvLongitude = findViewById(R.id.tvLongitude);
        btnGetLocation=findViewById(R.id.btnGetLocation);
        setAlarm=findViewById(R.id.setAlarm);

        // 현재위치 호출요소
        final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);


        //위치좌표 호출 버튼 이벤트 관리
        btnGetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //위치권한 검사
                if ( Build.VERSION.SDK_INT >= 23 &&
                        ContextCompat.checkSelfPermission( getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED ) {
                    ActivityCompat.requestPermissions( LocationAddActivity.this, new String[] {
                            android.Manifest.permission.ACCESS_FINE_LOCATION}, 0 );
                }
                else{
                    // 가장최근 위치정보 가져오기
                    location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if(location != null) {
                        lon = location.getLongitude();
                        lat = location.getLatitude();

                        tvLongitude.setText("Longitude: " + lon);
                        tvLatitude.setText("Latitude: " + lat);

                    }

                    // 위치정보를 원하는 시간, 거리마다 갱신해준다.
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                            1000,
                            1,
                            gpsLocationListener);
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                            1000,
                            1,
                            gpsLocationListener);
                    onMapReady(googleMap);
                }
            }
        });

        setAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LocationAddActivity.this, AlarmAddActivity.class);
                lon = location.getLongitude();
                lat = location.getLatitude();
                Log.d("좌표에러", lat+" "+lon);

                saveLocationToSharedPreferences(lat, lon);

                startActivity(intent);



            }
        });
    }

    //위치변화시
    final LocationListener gpsLocationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            // 위치 리스너는 위치정보를 전달할 때 호출되므로 onLocationChanged()메소드 안에 위지청보를 처리를 작업을 구현
            lat=  location.getLatitude();
            lon  = location.getLongitude();

        }
    };

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap=googleMap;
        googleMap.clear();
        LatLng location=new LatLng(lat,lon); //위도경도
        MarkerOptions markerOptions=new MarkerOptions();
        markerOptions.title("here");
        markerOptions.snippet("여기서 알람이 울려요");

        markerOptions.position(location);//위도경도를 마커에 넣어줌
        googleMap.addMarker(markerOptions);
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location,16));


    }

    private void saveLocationToSharedPreferences(double latitude, double longitude) {
        SharedPreferences preferences = getSharedPreferences("LocationPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("latitude", String.valueOf(latitude));
        editor.putString("longitude", String.valueOf(longitude));
        editor.apply();
    }

}