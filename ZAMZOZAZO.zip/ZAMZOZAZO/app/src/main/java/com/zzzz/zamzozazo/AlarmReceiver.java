package com.zzzz.zamzozazo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("리시버연결됨", "receiver");

        // 이전 액티비티에서 저장한 위치 정보 불러오기
        SharedPreferences preferences = context.getSharedPreferences("LocationPrefs", Context.MODE_PRIVATE);
        String savedLatitude = preferences.getString("latitude", "");
        String savedLongitude = preferences.getString("longitude", "");
        Log.d("리시브실행", "onReceive: ");

        // 현재 위치 정보 가져오기
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            Log.d("위치정보받음", "onReceive: ");
            try {
                locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        double currentLatitude = location.getLatitude();
                        double currentLongitude = location.getLongitude();
                        Log.d("나한테 왜그래", currentLatitude +" "+savedLatitude);
                        Log.d("나한테 왜그래", currentLongitude +" "+savedLongitude);

                        // 위치 비교
                        if (savedLatitude.equals(String.valueOf(currentLatitude)) &&
                                savedLongitude.equals(String.valueOf(currentLongitude))) {
                            // 위치가 같은 경우 Toast 메시지 표시
                            Log.d("비이동시 정상작동", "onLocationChanged: ");
                            Toast.makeText(context, "아직도 주무시는 군요...", Toast.LENGTH_SHORT).show();
                            Intent newIntent = new Intent(context, WakeUP.class);
                            newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(newIntent);



                        } else {Log.d("이동시 정상작동", "onLocationChanged: ");
                            Toast.makeText(context, "\n\n\uD83D\uDE42\uD83D\uDE42\n사용자의 움직임이 감지되었습니다.\n메인화면으로 돌아갑니다.\n\uD83D\uDE42\uD83D\uDE42\n\n", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(context, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            context.startActivity(intent);

                        }
                    }


                }, null);
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }
    }
}
