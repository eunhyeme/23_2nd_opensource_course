package com.zzzz.zamzozazo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AlarmAddActivity extends AppCompatActivity {


        private TimePicker timePicker;
        private Button btnGetTime;

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_alarmadd);

            timePicker = findViewById(R.id.timePicker);
            timePicker.setIs24HourView(true);
            btnGetTime = findViewById(R.id.btn_gettime);

            btnGetTime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 버튼이 클릭되었을 때 호출되는 부분

                    // 현재 선택된 시간 가져오기
                    int hour = timePicker.getHour();
                    int minute = timePicker.getMinute();

                    // 가져온 시간을 사용하여 작업 수행
                    String selectedTime = hour + "시 " + minute+"분";
                    Toast.makeText(AlarmAddActivity.this, "Selected Time: " + selectedTime, Toast.LENGTH_SHORT).show();

                    //알람만들기
                    Intent intent=new Intent(AlarmAddActivity.this, StartAlarmActivity.class);
                    intent.putExtra("Time",selectedTime);
                    setAlarm();


                    startActivity(intent);
                }
            });

        }
    private void setAlarm() {
            String TAG="하 제발";
        int hour = timePicker.getCurrentHour();
        int minute = timePicker.getCurrentMinute();

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        Log.d(TAG, "setAlarm: 1");

        Intent intent = new Intent(AlarmAddActivity.this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmAddActivity.this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Log.d(TAG, "setAlarm: 2");
        if (alarmManager != null) {
            Log.d(TAG, "setAlarm: 3");
            // Set the alarm to wake up the device at the specified time.
            alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        }
    }

}