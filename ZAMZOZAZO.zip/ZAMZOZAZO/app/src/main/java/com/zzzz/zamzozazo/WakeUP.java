package com.zzzz.zamzozazo;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.zzzz.zamzozazo.R;

public class WakeUP extends AppCompatActivity {

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wake_up);

        // MP3 파일 재생
        mediaPlayer = MediaPlayer.create(this, R.raw.bbibbi);
        mediaPlayer.setLooping(true); // 반복 재생 설정
        mediaPlayer.start();

        // 이미지 표시
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.image);

        // 종료 버튼
        Button closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        // 액티비티가 종료될 때 MediaPlayer를 해제
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        super.onDestroy();
    }
}
